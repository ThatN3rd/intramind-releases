# EBMS Live - pull latest release from GitHub and restart the server
# Runs automatically every 6 hours via Windows Task Scheduler (as SYSTEM).
# Can also be run manually as Administrator.

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = "Stop"
$INSTALL_DIR   = "C:\Program Files\IntraMind"
$DATA_DIR      = "C:\ProgramData\IntraMind"
$AGENT_SERVICE = "EBMSLiveAgent"
$LOG_FILE      = "$DATA_DIR\update.log"
$TASK_NAME     = "IntraMindAutoUpdate"

$MANIFEST_URLS = @{
    stable = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases/main/manifest.json"
    beta   = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases-beta/main/manifest.json"
}

function Log($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Cyan
}
function Warn($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') WARNING: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Yellow
}
function Fail($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ERROR: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Red
    exit 1
}

Log "EBMS Live Updater starting"

# --- Register scheduled task if not already present ---
$task = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if (-not $task) {
    Log "Registering auto-update scheduled task (every 6 hours)..."
    $action    = New-ScheduledTaskAction -Execute "powershell.exe" `
                   -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$INSTALL_DIR\update.ps1`""
    $trigger   = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Hours 6) -Once -At "00:00"
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
    $settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) `
                   -StartWhenAvailable -MultipleInstances IgnoreNew
    Register-ScheduledTask -TaskName $TASK_NAME -Action $action -Trigger $trigger `
        -Principal $principal -Settings $settings -Force | Out-Null
    Log "Scheduled task registered."
}

# --- Read config from .env ---
$PORT = "8767"; $CHANNEL = "stable"
if (Test-Path "$DATA_DIR\.env") {
    foreach ($line in Get-Content "$DATA_DIR\.env") {
        if ($line -match "^EBMS_LIVE_PORT=(.+)$")    { $PORT    = $Matches[1].Trim() }
        if ($line -match "^EBMS_LIVE_CHANNEL=(.+)$") { $CHANNEL = $Matches[1].Trim().ToLower() }
    }
}
if (-not $MANIFEST_URLS.ContainsKey($CHANNEL)) { $CHANNEL = "stable" }
$MANIFEST_URL = $MANIFEST_URLS[$CHANNEL]
Log "Channel: $CHANNEL"

# --- Check current running version ---
$versionBefore = "unknown"
try {
    $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 5
    $versionBefore = ($resp.Content | ConvertFrom-Json).version
} catch {}

# --- Fetch manifest from latest release (no auth required) ---
$manifest = $null
try {
    $raw = Invoke-WebRequest -Uri $MANIFEST_URL -UseBasicParsing -TimeoutSec 15
    $manifest = $raw.Content | ConvertFrom-Json
} catch {
    Fail "Could not fetch update manifest from $MANIFEST_URL -- check network connection."
}

$latestVersion = $manifest.version
$zipUrl        = $manifest.zip_url
$expectedSha   = $manifest.sha256
$whatsNew      = $manifest.whats_new

# The beta manifest tags versions as "x.y.z-beta", but /health reports the bare
# "x.y.z" from server.py. Strip any pre-release suffix from both sides before
# comparing so a beta box doesn't see itself as perpetually out of date and
# re-install (and restart the service) on every cycle.
$latestCompare = ($latestVersion -split '-')[0]
$beforeCompare = ($versionBefore -split '-')[0]

if ($latestCompare -eq $beforeCompare) {
    Log "Already up to date (version $versionBefore) -- skipping."
    exit 0
}

Log "Updating: $versionBefore -> $latestVersion"

# --- Download release zip ---
$zipPath = "$env:TEMP\intramind-release.zip"
try {
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
    Log "Downloaded release zip."
} catch {
    Fail "Failed to download release zip from $zipUrl"
}

# --- Verify SHA256 checksum ---
$actualSha = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
if ($actualSha -ne $expectedSha.ToLower()) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Fail "Checksum mismatch. Expected: $expectedSha  Got: $actualSha -- aborting update."
}
Log "Checksum verified."

# --- Extract to install dir ---
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    foreach ($entry in $zip.Entries) {
        $destPath = Join-Path $INSTALL_DIR $entry.FullName
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destPath, $true)
        Log "  Extracted $($entry.FullName)"
    }
    $zip.Dispose()
} catch {
    Fail "Failed to extract release zip: $_"
} finally {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
}

# --- Write pending update notification for UI ---
$pending = @{ version = $latestVersion; whats_new = $whatsNew } | ConvertTo-Json -Compress
Set-Content "$DATA_DIR\pending_update.txt" $pending -NoNewline
Log "Pending update notification written for version $latestVersion"

# --- Migrate legacy "Cloudflared" service name to "IntramindCloudServices" ---
# Renamed to avoid colliding with other Cloudflare Tunnel products (e.g. Koble)
# that use the default service name. install.ps1 does this migration on a fresh
# reinstall, but most customers only ever get auto-updated and never re-run the
# installer, so do it here too. NEVER touch a service just because it's named
# "Cloudflared": on a shared machine that name might belong to another product.
# Verify ownership by binPath first -- this runs unattended every 6 hours, so an
# unverified assumption here means silently deleting someone else's service on a
# schedule. See docs/cloudflared-tunnel-setup.md Troubleshooting for the
# 2026-07-16 mmp-ebms incident this check exists to prevent.
$CF_SYS_DIR = "C:\Windows\System32\config\systemprofile\.cloudflared"
$CF_SERVICE_NAME = "IntramindCloudServices"
$legacyCfSvc = Get-CimInstance Win32_Service -Filter "Name='Cloudflared'" -ErrorAction SilentlyContinue
if ($legacyCfSvc -and $legacyCfSvc.PathName -like "*$CF_SYS_DIR*") {
    Log "Found legacy IntraMind 'Cloudflared' service - migrating to $CF_SERVICE_NAME..."
    $legacyBinPath = $legacyCfSvc.PathName
    $wasRunning = ($legacyCfSvc.State -eq "Running")
    Stop-Service "Cloudflared" -Force -ErrorAction SilentlyContinue
    sc.exe delete Cloudflared | Out-Null
    sc.exe create $CF_SERVICE_NAME binPath= $legacyBinPath start= auto DisplayName= "IntraMind Cloud Services" | Out-Null
    sc.exe failure $CF_SERVICE_NAME reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    if ($wasRunning) { Start-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue }
    Log "Migrated to $CF_SERVICE_NAME."
} elseif ($legacyCfSvc) {
    Warn "A 'Cloudflared' service exists but is not owned by IntraMind (binPath: $($legacyCfSvc.PathName)). Leaving it untouched."
}

# --- Ensure the IntraMind cloudflared tunnel service is running ---
$svcInfo = Get-CimInstance Win32_Service -Filter "Name='$CF_SERVICE_NAME'" -ErrorAction SilentlyContinue
if ($svcInfo -and $svcInfo.PathName -like "*$CF_SYS_DIR*") {
    $cfSvc = Get-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue
    if ($cfSvc.Status -ne "Running") {
        Log "$CF_SERVICE_NAME was not running - starting it..."
        Start-Service $cfSvc.Name -ErrorAction SilentlyContinue
        Log "$CF_SERVICE_NAME started."
    }
} elseif ($svcInfo) {
    Warn "Service '$CF_SERVICE_NAME' exists but is not owned by IntraMind (binPath: $($svcInfo.PathName)). Not touching it."
} else {
    Warn "IntraMind's own cloudflared tunnel service not found - tunnel may be down."
}

# --- Restart agent service ---
Log "Restarting $AGENT_SERVICE..."
Restart-Service $AGENT_SERVICE -ErrorAction Stop
Log "Service restarted."

# --- Verify new version ---
Start-Sleep -Seconds 5
$versionAfter = "unknown"
for ($i = 0; $i -lt 10; $i++) {
    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
        if ($resp.StatusCode -eq 200) {
            $versionAfter = ($resp.Content | ConvertFrom-Json).version
            break
        }
    } catch {}
    Start-Sleep -Seconds 2
}

if ($versionAfter -eq "unknown") {
    Warn "Server not responding after restart -- check $DATA_DIR\agent.log"
} else {
    Log "Update complete. Version: $versionAfter"
}
