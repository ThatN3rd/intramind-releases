import logging

class SuppressEndpoints(logging.Filter):
    def __init__(self, endpoints=None):
        super().__init__()
        self.endpoints = endpoints or []

    def filter(self, record):
        msg = record.getMessage()
        return not any(ep in msg for ep in self.endpoints)
